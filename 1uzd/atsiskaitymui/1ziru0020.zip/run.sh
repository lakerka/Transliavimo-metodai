#
# Vykdomasis failas skirtas UNIX aplinkai.
#
# Kursas "Transliavimo metodai" (TMET2114) 2014/2015 m. rudens semestras
# Atliko: Žilvinas Rudžionis, Programų sistemos, 3 grupė, 118 variantas
#

#!/bin/sh
./skan Sample25.trm result
